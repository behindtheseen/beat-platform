-- Run this AFTER tables are created
INSERT INTO beats (title, bpm, key, genre, price, exclusive_price, audio_url, cover_url, is_exclusive, status) VALUES
('Night Drive', 140, 'Cm', 'Trap', 29.99, 299.99, 'https://files.freemusicarchive.org/storage-freemusicarchive-org/music/no_curator/Tours_En_Version_Originale/01_-_Sense_Ayou/Tours_-_01_-_Sense_Ayou.mp3', 'https://picsum.photos/400/400', false, 'active'),
('Summer Vibes', 100, 'G', 'Pop', 24.99, 249.99, 'https://files.freemusicarchive.org/storage-freemusicarchive-org/music/no_curator/KieLoKaz_-_Free_Ganymed/01_-_Reunion_of_the_Spirits/KieLoKaz_-_01_-_Reunion_of_the_Spirits.mp3', 'https://picsum.photos/401/401', false, 'active'),
('Dark Knight', 95, 'Bm', 'Hip Hop', 34.99, 349.99, 'https://files.freemusicarchive.org/storage-freemusicarchive-org/music/no_curator/Dee_Yan-Kee/Yellow_Dog/Dee_Yan-Kee_-_01_-_Yellow_Dog.mp3', 'https://picsum.photos/402/402', false, 'active');
